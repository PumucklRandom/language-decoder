from typing import Literal

BoxDecorationBreak = Literal[
    'clone',
    'slice',
]
