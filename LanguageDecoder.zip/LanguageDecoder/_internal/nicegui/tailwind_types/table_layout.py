from typing import Literal

TableLayout = Literal[
    'auto',
    'fixed',
]
