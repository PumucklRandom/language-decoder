from typing import Literal

BackdropInvert = Literal[
    '0',
    '',
]
