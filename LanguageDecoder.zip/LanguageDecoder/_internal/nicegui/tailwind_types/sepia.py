from typing import Literal

Sepia = Literal[
    '0',
    '',
]
