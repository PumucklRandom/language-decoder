from typing import Literal

FontStyle = Literal[
    'italic',
    'not-italic',
]
