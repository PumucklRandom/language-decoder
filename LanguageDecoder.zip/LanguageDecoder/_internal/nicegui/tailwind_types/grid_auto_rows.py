from typing import Literal

GridAutoRows = Literal[
    'auto',
    'min',
    'max',
    'fr',
]
