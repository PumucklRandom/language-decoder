from typing import Literal

Visibility = Literal[
    'visible',
    'invisible',
    'collapse',
]
