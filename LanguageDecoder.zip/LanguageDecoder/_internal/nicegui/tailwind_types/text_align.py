from typing import Literal

TextAlign = Literal[
    'left',
    'center',
    'right',
    'justify',
    'start',
    'end',
]
