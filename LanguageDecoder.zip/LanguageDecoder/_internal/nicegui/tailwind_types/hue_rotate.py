from typing import Literal

HueRotate = Literal[
    '0',
    '15',
    '30',
    '60',
    '90',
    '180',
]
