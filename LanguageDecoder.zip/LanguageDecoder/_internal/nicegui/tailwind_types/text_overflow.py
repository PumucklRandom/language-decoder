from typing import Literal

TextOverflow = Literal[
    'truncate',
    'text-ellipsis',
    'text-clip',
]
