from typing import Literal

Grayscale = Literal[
    '0',
    '',
]
