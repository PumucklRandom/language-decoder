from typing import Literal

ScrollSnapStop = Literal[
    'normal',
    'always',
]
