from typing import Literal

ListStyleImage = Literal[
    'none',
]
