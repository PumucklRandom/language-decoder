from typing import Literal

WillChange = Literal[
    'auto',
    'scroll',
    'contents',
    'transform',
]
