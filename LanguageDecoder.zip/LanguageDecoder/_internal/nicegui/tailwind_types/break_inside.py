from typing import Literal

BreakInside = Literal[
    'auto',
    'avoid',
    'avoid-page',
    'avoid-column',
]
