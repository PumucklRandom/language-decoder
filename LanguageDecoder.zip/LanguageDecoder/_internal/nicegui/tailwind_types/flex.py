from typing import Literal

Flex = Literal[
    '1',
    'auto',
    'initial',
    'none',
]
