from typing import Literal

Resize = Literal[
    'none',
    'y',
    'x',
    '',
]
