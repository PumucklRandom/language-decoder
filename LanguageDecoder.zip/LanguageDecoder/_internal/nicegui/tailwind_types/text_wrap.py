from typing import Literal

TextWrap = Literal[
    'wrap',
    'nowrap',
    'balance',
    'pretty',
]
