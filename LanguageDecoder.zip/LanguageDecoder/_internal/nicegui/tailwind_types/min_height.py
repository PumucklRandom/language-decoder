from typing import Literal

MinHeight = Literal[
    '0',
    'full',
    'screen',
    'min',
    'max',
    'fit',
]
