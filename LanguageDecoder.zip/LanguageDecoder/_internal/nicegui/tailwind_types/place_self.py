from typing import Literal

PlaceSelf = Literal[
    'auto',
    'start',
    'end',
    'center',
    'stretch',
]
