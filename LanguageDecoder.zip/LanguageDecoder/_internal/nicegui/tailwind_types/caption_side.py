from typing import Literal

CaptionSide = Literal[
    'top',
    'bottom',
]
