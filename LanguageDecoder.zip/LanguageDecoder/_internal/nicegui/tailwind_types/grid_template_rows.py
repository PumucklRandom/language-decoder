from typing import Literal

GridTemplateRows = Literal[
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    'none',
]
