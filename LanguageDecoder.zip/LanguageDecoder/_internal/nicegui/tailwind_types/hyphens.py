from typing import Literal

Hyphens = Literal[
    'none',
    'manual',
    'auto',
]
