from typing import Literal

BackgroundSize = Literal[
    'auto',
    'cover',
    'contain',
]
