from typing import Literal

Saturate = Literal[
    '0',
    '50',
    '100',
    '150',
    '200',
]
