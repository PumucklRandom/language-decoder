from typing import Literal

ListStylePosition = Literal[
    'inside',
    'outside',
]
