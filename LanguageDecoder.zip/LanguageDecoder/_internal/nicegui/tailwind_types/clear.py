from typing import Literal

Clear = Literal[
    'left',
    'right',
    'both',
    'none',
]
