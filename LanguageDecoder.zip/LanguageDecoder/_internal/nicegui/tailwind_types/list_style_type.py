from typing import Literal

ListStyleType = Literal[
    'none',
    'disc',
    'decimal',
]
