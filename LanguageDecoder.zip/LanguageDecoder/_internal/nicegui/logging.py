import logging

log: logging.Logger = logging.getLogger('nicegui')
